<?php
/**
 * @file
 * std2 style loader.
 */
  $prodversion = defined('EASYCONTACTFORMS__prodVersion') ? '?ver=' . EASYCONTACTFORMS__prodVersion : '';
?><link href='<?php echo EASYCONTACTFORMS__engineWebAppDirectory;?>/styles/std2/css/std.css<?php echo $prodversion;?>' rel='stylesheet' type='text/css'/><link href='<?php echo EASYCONTACTFORMS__engineWebAppDirectory;?>/styles/std2/css/icons.css<?php echo $prodversion;?>' rel='stylesheet' type='text/css'/><link href='<?php echo EASYCONTACTFORMS__engineWebAppDirectory;?>/styles/std2/css/sizes.css<?php echo $prodversion;?>' rel='stylesheet' type='text/css'/>