<?php
/**
 * @file
 * formscompressed style loader.
 */
  $prodversion = defined('EASYCONTACTFORMS__prodVersion') ? '?ver=' . EASYCONTACTFORMS__prodVersion : '';
?><link href='<?php echo EASYCONTACTFORMS__engineWebAppDirectory;?>/forms/styles/formscompressed/css/std.css<?php echo $prodversion;?>' rel='stylesheet' type='text/css'/><link href='<?php echo EASYCONTACTFORMS__engineWebAppDirectory;?>/forms/styles/formscompressed/css/icons.css<?php echo $prodversion;?>' rel='stylesheet' type='text/css'/>