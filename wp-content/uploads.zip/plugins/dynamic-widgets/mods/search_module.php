<?php
/**
 * Search Module
 *
 * @version $Id: search_module.php 523481 2012-03-25 19:49:08Z qurl $
 * @copyright 2011 Jacco Drabbe
 */

	class DW_Search extends DWModule {
		public static $option = array( 'search' => 'Search page' );
		protected static $question = 'Show widget on the search page?';
	}
?>